import 'package:tourist_travel_app/components/everyImport.dart';
class ImagePath{
  static path(String value){
    return listOfPlaces[value];
  }
}

class LocationName{
  static path(String value){
    return listOfLocationNames[value];
  }
}